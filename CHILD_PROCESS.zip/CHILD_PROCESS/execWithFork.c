#include<stdio.h>
#include<unistd.h>
#include<sys/wait.h>
#include<string.h>

int main(int arg, char* argv[]){
    int cpid, status;
    printf("Parent process id: %d\n",getpid());

    cpid = fork();

    if(cpid==0){
        printf("\nChild id:%d",getpid());
        execl("./ewf1", "arg1", "arg2", "arg3", NULL);
        printf("\nLine isn't printed");
        exit(1);
    }
    else {
        printf("\nParent id: %d",getpid());
        printf("\nChild process created by the parent: %d",cpid); // child process id
        cpid = wait(&status);
        printf("cpid: %d\n",cpid);
        printf("status is: %d\n",status);
    }
}