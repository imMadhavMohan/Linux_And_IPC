#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>

int main(){
    char* argv[] = {"Welcome","Madhav","Mohan",NULL};
    char* envc[] = {"E1=10", "E2=20", "E3=30", "E4=40", NULL};

    execve("./execve1", argv, envc);
    printf("It wont execute");
    exit(0);
}