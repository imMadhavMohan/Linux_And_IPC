#include<stdio.h>
#include<string.h>
#include<unistd.h>
#include<sys/types.h>
#include<wait.h>
#include<stdlib.h>

// When the main program executes fork(), an identical copy of its address space, including the program and all data, is
// created. System call fork() returns the child process ID to the parent and returns 0 to the child process. 
// The following figure shows that in both address spaces there is a variable pid. The one in the parent receives the
// child's process ID 3456 and the one in the child receives 0.

int main(){
    pid_t id; // 0 or -1
    int status = 0;
    printf("Parent process: Exe before fork() - PID = %d\n",getpid()); // parent as child hasn't been created
    id = fork(); // create child

    if(id<0){
        printf("fork fail\n");
        exit(-1);
    }
    
    if(id==0){ // child process got id = 0
        printf("\nI'm child process: %d\n",id);
        sleep(5);
        printf("\nThe creator of child process: %d\n",getpid()); // child id
        printf("\nThe creator of child process: %d\n",getppid()); // parent id
        exit(3);
    }
    else { // parent process got child p_id means created successfully
        printf("Im parent\n");
        id = wait(&status);  // as child exit it return a val, if lhs bits are bin 3 and 
                             // lower bits are rhs bits are 0000       
        printf("Wait in parent is done, parent id = %d\n",getpid()); // parent id
        printf("\nParent created - child process with id: %d\n",id);
        printf("status is: %d\n",status);
    }
    // 768 = 0111 0110 1000 0000
    return 0;
}