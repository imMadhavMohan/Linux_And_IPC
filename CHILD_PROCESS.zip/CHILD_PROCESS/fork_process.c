#include<stdio.h>
#include<string.h>
#include<unistd.h>
#include<sys/types.h>
#include<stdlib.h>

// When the main program executes fork(), an identical copy of its address space, including the program and all data, is
// created. System call fork() returns the child process ID to the parent and returns 0 to the child process. 
// The following figure shows that in both address spaces there is a variable pid. The one in the parent receives the
// child's process ID 3456 and the one in the child receives 0.

int main(){
    pid_t id; // 0 or -1
    printf("Parent process: Exe before fork() - PID = %d\n ",getpid()); // parent as child hasn't been created
    id = fork(); // create child

    if(id<0){
        printf("fork fail\n");
        exit(-1);
    }

    if(id>0){ // = 0 means created successfully
        printf("\nParent created child process with id: %d\n",id);
    }
    else{
        printf("\nI'm child process: %d\n",id);
        printf("\nThe creator of child process: %d\n",getpid());
        printf("\nThe creator of child process: %d\n",getppid()); // parent
    }
}