#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<string.h>

int main(int arg, char* argv[]){
    printf("New process called by excel()");
    printf("\nProcess-id: %d",getpid());
    for(int i=0;i<arg;i++){
        printf("\n argv[%d] = %s", i, argv[i]);
    }
    sleep(5);
    exit(0);
}