#include<string.h>
#include<stdio.h>
#include<unistd.h>

int g_var = 5; // data-seg
static int st = 10; // data-seg
int addnum(int a,int b){return a+b;}

int main(){
    char *ptr; // Heap seg
    char buf[20] = "Hi Happy Diwali"; // can be modified - stack-seg
    char *buff = "Hi Happy Holi"; // can't be modified - text-seg

    strcpy(buf,"Hello Happy Diwali greet\n");

    int n1=3,n2=5; // stack frame
    int sum = addnum(n1,n2); // stack

    ptr = (char*)malloc(20); // Heap 
    strcpy(ptr, "Hello Madhav");
    printf("\nString stored: %s\n",ptr);

    return 0;
}