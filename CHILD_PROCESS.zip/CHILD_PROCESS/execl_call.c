#include<unistd.h>
#include<stdio.h>
#include<string.h>

int main(int arg, char* argv[]){
    printf("I'm new program called by execv() sys_call id: %d\n",getpid());
    for(int i=0;i<arg;i++){
        printf("\nargv[%d] = %s\n",i,argv[i]);
    }

    exit(0);
}