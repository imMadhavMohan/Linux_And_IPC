#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>

int main(){
    printf("Child process_id: %d\n",getpid());
    printf("Parent process_id: %d\n",getppid());

    return 0;
}