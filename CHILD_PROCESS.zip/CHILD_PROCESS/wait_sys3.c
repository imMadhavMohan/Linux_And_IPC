#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <wait.h>
#include <stdlib.h>

// Non-Blocking call we can execute new instruction no need to wait

int main()
{
    pid_t cid1;
    pid_t cid2;
    int status;
    printf("\nParent id: %d\n", getpid());
    cid1 = fork(); // parent process fork 2nd child

    if (cid1 < 0)
    {
        printf("\n Error in chd-1\n");
        exit(-1);
    }
    if (cid1 == 0)
        { // child
            printf("Child-1 id: %d\n", getpid());
            printf("Parent of Child-1 id: %d\n", getppid());
            sleep(5);
            exit(1);
        }
        else
        {
            int rid1 = waitpid(cid1,&status,0);
            printf("cpid1 returns: %d\n",rid1);
            cid2 = fork(); // parent process fork 2nd child
            printf("Parent of Child-2 id: %d\n", getpid());
            if (cid2 < 0)
            {
                printf("\n Error in chd-2\n");
                exit(-1);
            }

            sleep(5);

            if (cid2 == 0)
            { // chld-2
                printf("Child-2 id: %d\n", getpid());
                printf("Parent id of Child-2: %d\n", getppid());
                sleep(5);
                exit(1);
            }
            else
            { // chld-1 (Parent)
                rid1 = waitpid(cid2,&status,WNOHANG);
                printf("cpid2 returns is: %d",rid1);
                printf("\nParent of chld-2: %d\n",getpid());
            }        
    }
    return 0;
}