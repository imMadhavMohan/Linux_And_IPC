#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>

extern char **enviorn;

int main(int arg, char* argv[]){
    
    for(int i=0;i<arg;i++){
        printf("argv[%d] = %s\n",i,argv[i]);        
    }

    printf("\n");
    for(char** ep = enviorn;*ep!=NULL;ep++){
        printf("\nenviorn: %s\n",*ep);
    }

    exit(0);
}