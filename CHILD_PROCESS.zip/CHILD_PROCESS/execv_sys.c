#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>


int main(){
    printf("\nI'm main process pid = %d",getpid());
    char* args[5] = {"Hello", "Madhav", "Mohan", "Come", NULL};
    execv("./execv1",args); // Pass Object file of other prog

    printf("\nThis line will not be printed\n");

    exit(0);
    return 0;
}