#include<unistd.h>
#include<stdio.h>

int main(){
    printf("\nI'm main process pid = %d",getpid());
    execl("./execl1","arg1","arg2","arg3","arg4",NULL); // Pass Object file of other prog
    printf("\nThis line will not be printed\n");
    exit(0);
    return 0;
}