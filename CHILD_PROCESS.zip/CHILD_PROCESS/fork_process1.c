#include<stdio.h>
#include<string.h>
#include<unistd.h>
#include<sys/types.h>
#include<stdlib.h>

// When the main program executes fork(), an identical copy of its address space, including the program and all data, is
//  created. System call fork() returns the child process ID to the parent and returns 0 to the child process. 
//  The following figure shows that in both address spaces there is a variable pid. The one in the parent receives the
//   child's process ID 3456 and the one in the child receives 0.



static int gdata = 111;

int main(){
    int stackdata = 222;
    pid_t id;

    switch (id = fork())
    {
    case -1:
        printf("\n error in fork()");
        break;
    case 0: // child id = 0
        printf("\nI'm child process");
        gdata*=3; stackdata*=3;
        printf("\nstackdata = (%d) , gdata = (%d) , id = (%d)\n",stackdata,gdata,id);
        break;    
    default:  // parent id = child p_id
        // whatever change we make is visible to its scope only
        printf("\nI'm parent");
        printf("\nstackdata = (%d) , gdata = (%d) , id = (%d)\n",stackdata,gdata,id);
        sleep(5);
        break;
    }    
    exit(0);
}