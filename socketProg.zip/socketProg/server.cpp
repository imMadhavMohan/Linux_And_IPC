#include <iostream>
#include <sys/types.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <string.h>
#include <string>

#define PORT 4043

using namespace std;

int main()
{
    // Create a socket
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock == -1)
    {
        cerr << "Can't create a socket! Quitting" << endl;
        return -1;
    }

    // DEFINITION:
    //     struct sockaddr_in
    //     {
    //       short sin_family;
    //       u_short sin_port;
    //       struct  in_addr sin_addr;
    //       char sin_zero[8];
    //     }; // A sockaddr_in is a structure containing an internet address
    // socklen_t  is an integer type of width of at least 32 bits


    // Bind the ip address and port to the socket of serv_add
    sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = htons(INADDR_ANY);  // INADDR_ANY contains the IP address of the host.
    addr.sin_port = htons(PORT);   //  htons() converts the port number from host byte order,
                                   // to a port number in network byte order.
    inet_pton(AF_INET, "0.0.0.0", &addr.sin_addr);
    //  The InetPton function converts an IPv4 or IPv6 Internet network address,
    // in its standard text presentation form into its numeric binary form

    bind(sock, (sockaddr*)&addr, sizeof(addr));

    // Tell Winsock the socket is for sock
    listen(sock, SOMAXCONN);

    // Wait for a connection
    sockaddr_in client; // we can also use char client[]
    socklen_t clientSize = sizeof(client);

    int clientSocket = accept(sock, (sockaddr*)&client, &clientSize);

    char host[NI_MAXHOST];      // Client's remote name
    char service[NI_MAXSERV];   // Service (i.e. port) the client is connect on

    // Close sock socket
    close(sock);

    // While loop: accept and echo message back to client
    char buf[4096];

    while (true)
    {
        memset(buf, 0, 4096);

        // Wait for client to send data
        int bytesReceived = recv(clientSocket, buf, 4096, 0);
        if (bytesReceived == -1)
        {
            cerr << "Error in recv(). Quitting" << endl;
            break;
        }

        if (bytesReceived == 0)
        {
            cout << "Client disconnected " << endl;
            break;
        }

        cout << string(buf, 0, bytesReceived) << endl;

        // Echo message back to client
        send(clientSocket, buf, bytesReceived + 1, 0);
    }

    // Close the socket
    close(clientSocket);

    return 0;
}