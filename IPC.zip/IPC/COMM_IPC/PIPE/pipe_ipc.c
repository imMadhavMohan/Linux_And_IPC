#include<fcntl.h>
#include<stdio.h>
#include<unistd.h>
#include<string.h>
#include<stdlib.h>

int main(){
    int fd[2]; // file discriptor for read & write
    char buf[50];
    char data[]={};

    // pipe take arr of 2 int as arg
    if(pipe(fd)==-1){ // open pipe
        perror("pipe");
        exit(1); // exit from prog
    }

    // fd[0] is for reading end
    sprintf(buf,"Pipe for data flow demo");

    // writing to pipe
    write(fd[1],buf,strlen(buf));
    printf("\n");

    // reading from pipe
    read(fd[0],data,5); // read 5 byte of received msg
    printf("read 5 byte data: %s\n",data);

    // reading from pipe
    read(fd[0],data,10);
    printf("read 10 byte data: %s\n",data);

}