#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include<sys/wait.h>

#define max 50

int main(int argc, char *argv[])
{
    int fd[2]; // read & write
    char buf[max] = {};
    ssize_t numread;

    /* Pipe descriptor*/
    if (pipe(fd) == -1)
    {
        perror("Exit -1");
        exit(-1);
    }

    switch (fork())     // child is created
    { 
    case -1:
        exit(-1);

    // pipe created
    case 0:  // child will execute
        if (close(fd[1]) == -1) //if write end is unused so reading is useless
            exit(-1);
        while(1){
            strcpy(buf,""); // read data from pipe
            numread = read(fd[0],buf,max);
            if(numread==0) {printf("child: parent has closed write node\n"); break;}
            
            if (numread == -1)
                exit(-1);

            if (numread == 0){
                printf("\n child: parent closed write end\n");                    
                break;
            }    
            /*End of file*/
            printf("\n data read from write fd[1] end is: %s\n",buf);            
            }
            if(close(fd[0])==-1)
                exit(-1);        
        break;
        
    default: // Parent will execute   
        /*Parent writes to pipe*/
        if(close(fd[0])==-1) //if read end is unused so writing is useless
            exit(-1);
        printf("\nsending user input to child\n");

        write(fd[1],argv[1],strlen(argv[1]));        
        sleep(2);
        if(close(fd[1]) == -1) // close write end
            exit(-1);
        printf("\nParent: closed write end\n");
        wait(NULL); // wait for child 
        exit(0);
    }
}