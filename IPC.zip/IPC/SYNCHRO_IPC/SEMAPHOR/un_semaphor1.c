#include <stdio.h>
#include <fcntl.h>
#include <semaphore.h>
#include <sys/stat.h>
#include <pthread.h>
#include <sys/types.h>
#include <unistd.h>

static int gvar = 0;

sem_t sem; // not defined as ptr like named semaphor

static void *fun(void *arg)
{
    int ret;
    printf("Thread %s is running\n", (char *)arg);

    ret = sem_wait(&sem);
    printf("semaphr is made avail to %s\n\n", (char *)arg);
    if (ret != 0)
        perror("Wait error");
    sleep(5);
    printf("critical sec begin for %s>>\n", (char *)arg);

    for (int i = 0; i < 1000; i++)
        gvar++;
    ret = sem_post(&sem);

    printf("\nProcess %s\n", (char *)arg);

    if (ret != 0)
        perror("Wait error");
    printf("critical sec end for %s>>\n\n", (char *)arg);

    return NULL;
}

int main()
{
    pthread_t t1, t2, t3;
    int s;

    s = pthread_create(&t1, NULL, fun, "thread-1"); // struct attr = NULL
    if (s != 0)
        perror("thread error");

    s = pthread_create(&t2, NULL, fun, "thread-2");
    if (s != 0)
        perror("thread error");

    s = pthread_create(&t3, NULL, fun, "thread-3");
    if (s != 0)
        perror("thread error");

    if (sem_init(&sem, 0, 2) == -1)
    { // cnt = 2 so only Two process can access in critical section
        perror("Error in sem_open()");
        return -1;
    }

    s = pthread_join(t1, NULL); // return nothing
    if (s != 0)
        perror("Thread-1 error");

    s = pthread_join(t2, NULL); // return nothing
    if (s != 0)
        perror("Thread-2 error");

    s = pthread_join(t3, NULL); // return nothing
    if (s != 0)
        perror("Thread-3 error");

    if (sem_destroy(&sem) != 0)
        perror("Error in destroy");
    printf("Gavr is: %d\n", gvar);

    return 0;
}