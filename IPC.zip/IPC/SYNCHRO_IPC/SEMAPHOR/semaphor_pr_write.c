// Named semaphor
#include<unistd.h>
#include<stdio.h>
#include<semaphore.h>
#include<fcntl.h>
#include<sys/stat.h>
#include<sys/types.h>

int main(){
    int sval;
    sem_t *sem;

    sem = sem_open("/semph", O_WRONLY|O_CREAT, 0660, 2); // semaphor val is given rationally

    if(sem==SEM_FAILED){
        perror("Error sem"); return -1;
    }

    sem_getvalue(sem,&sval);
    printf("sem val before wait():%d\n",sval);

    sem_wait(sem);  //-- if val>0 then only proces can enter
    printf("sem val after wait():%d\n",sval);

    printf("critical sec begin>>\n");
    printf("critical sec in process>>  <<\n");
    sleep(10);    
    sem_post(sem);  //++
    printf("critical sec ends>>\n");
    
    // sem_unlink("/semph");
    return 0;
}
