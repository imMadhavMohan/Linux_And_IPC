#include <stdio.h>
#include <pthread.h>
#include<string.h>
#include <stdlib.h>
#include <unistd.h>

void* fun(void* arg){
    printf("arg in thread is: %s",(char*)arg);
    while(1){
        sleep(1);
        printf("thread fun executing loop\n");
    }
    sleep(5); 
    printf("thread fun exits\n");
    pthread_exit(0);
}

int main(){
    pthread_t t;
    int s = pthread_create(&t,NULL,fun,"Hello Maddy_Mohan\n");

    if(s!=0)
        perror("error in create\n");

    for(int i=0;i<10;i++)
    {
        sleep(2); // this timer will show res in real time how 
                  // after cancel the thread the exe of thread stops
        printf("\ncount is: %d\n",i); 
    }
    
    pthread_cancel(t);
    printf("Main() exit\n");
    pthread_exit(0);
}