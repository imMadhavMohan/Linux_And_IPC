#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>

static void *fun(void *arg)
{
    char *str = (char *)arg;
    printf("The arg is: %s, & pid = %d\n", str, getpid());
    (void)sleep(2);
    printf("Exiting the thread\n");
    return(0);
}

int main()
{
    pthread_t t;
    int s;
    s = pthread_create(&t, NULL, fun, "Hello Mohan Come!"); // Null- no arg to be passed

    if (s != 0)
        printf("Error in execution\n");

    printf("main thread: Message from main(), pid = %d\n", getpid());

    sleep(5);

    printf("\nmain thread: exit() now\n");
    exit(0); // terminate all the sub threads & exit
}