#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>

static void *fun(void *arg)
{
    char *str = (char *)arg;
    printf("The arg is: %s, & pid = %d\n", str, getpid());        
    
    int i=0;
    for(i=0;i<100;i++); 
    sleep(10);
    printf("Thread fun exiting now\n");

    if(i<100)
        return (void*) "i<100"; // void fun as return type
    else 
        return (void*) "i>100"; 
}

int main()
{
    pthread_t t;
    int s;
    s = pthread_create(&t, NULL, fun, "Hello Mohan Come!"); // Null- no arg to be passed
    
    void *ret;
    if (s != 0)
        printf("Error in execution\n");

    printf("main thread: Message from main(), pid = %d\n", getpid());

    #if 1
        s = pthread_join(t, &ret);
        if(s!=0)
            perror("Pthread_join error\n");
        else 
            printf("in main thread: thread returns: %s",(char*)ret);
    #endif

    printf("\nmain thread: exit() now\n");
    pthread_exit(NULL); // terminate all the sub threads & exit; NULL ~ 0
}