#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

pthread_mutex_t my_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t myConVar = PTHREAD_COND_INITIALIZER;

int doneFlag = 0;
char buf[100];

/* Producer thread*/
void * threadA(void *p) {
    printf("\nthreadA Scheduled first\n");
    sleep(1);
    pthread_mutex_lock(&my_mutex);
    printf("\n threadA: critical section executes always first\n");

    /*producer will produce data here*/
    sprintf(buf,"This is data Buffer");
    for(int i=0;i<100;i++) doneFlag++;
    pthread_cond_signal(&myConVar);
    pthread_mutex_unlock(&my_mutex);
}

/*Consumer*/
void * threadB(void *p) {
    printf("\nthreadB Scheduled first\n");
    pthread_mutex_lock(&my_mutex);

    if (!doneFlag) // donedoneFlag == 0
        pthread_cond_wait(&myConVar, &my_mutex); // mtx is unlocked & mtx lock is acquired by threadA
                                        // once signal received from producer lock again acquired

    printf(" threadB: signal received from threadA, this is always executed after threadA critical section %d\n", doneFlag);
    
    /*consumer will consume data here*/
    for(int i=0;doneFlag>0;i++) doneFlag--;    
    printf("flag after consumer: %d",doneFlag);
    printf("\nThe buffer received from producer thread is (%s)\n",buf);

    pthread_mutex_unlock(&my_mutex);
}


int main(int argc, char** argv) {
    pthread_t pthreadA;
    pthread_create(&pthreadA, NULL, threadA, NULL);

    pthread_t pthreadB;
    pthread_create(&pthreadB, NULL, threadB, NULL);

    pthread_join(pthreadA,NULL);
    pthread_join(pthreadB,NULL);
    printf("\n Main thread is exiting now\n");
    return (EXIT_SUCCESS);
}
