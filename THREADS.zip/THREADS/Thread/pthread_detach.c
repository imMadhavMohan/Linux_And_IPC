#include <stdio.h>
#include <pthread.h>
#include<string.h>
#include <stdlib.h>
#include <unistd.h>

void *fun(void *arg){
    char *str = (char*)arg;
    printf("thread: %s",str);
    pthread_detach(pthread_self());
    sleep(5);
    printf("thread exits\n"); // no need to wait(or join) by main thread, 
                              // resources are vacated once exe finish  
}

int main(){
    pthread_t t;
    int s;
    s = pthread_create(&t,NULL,fun,"Come Maddy Mohan\n");

    if(s!=0)
        perror("Fail thread creation\n");
    // sleep(10);
    printf("Main thread exit\n");

    pthread_exit(NULL); // main thread waits for execution of thread
    return 0;
}