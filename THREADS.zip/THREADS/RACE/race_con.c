#include<stdio.h>

#include<unistd.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<fcntl.h>

#include<string.h>
#include<stdlib.h>
#include<malloc.h>

void main(){
    int fd, w; 
    char buf[50]={'\0'};
    for(int i=0;i<50;i++)
        buf[i] = 'M';
    
    buf[50]='\0';
    char buf2[1]={'\n'};

    fd = open("race.txt", O_RDWR);

    for(int i=0;i<5;i++){
        w = write(fd,buf,strlen(buf));
        w = write(fd,buf2,1);
    }    
    printf("\nExecuted-2\n");
    close(fd);
    
}