#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#include<unistd.h>
#include<fcntl.h>

int main(){
    int fd, sz;
    char buf[20]={0};
    fd = open("text.txt", O_RDONLY);
    if(fd<0){
        printf("\nError Occurs\n");
        perror("ERROR-");
        exit(1);
    }

    sz = read(fd, buf, 10); // read only 10 buyes
    buf[sz] = '\0'; // place empty cahr at the end
    printf("Read info is: ! %s !",buf);
    printf("\nByte return is: %d & fd status: %d\n", sz,fd);
    
    return 0;
}