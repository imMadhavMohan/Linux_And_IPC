#include<stdio.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<errno.h>

// if file isn't present so in this case we can use the O_CREAT cmnd

int main(){
    int fd = open("text.txt",O_WRONLY | O_CREAT | O_EXCL, 776); // got the file, 'chmod access flag'
    
    // if the file is already present then O_EXCL give o/p with error msg

    if(fd<0){ // if file permission contradicts then also error comes
        printf("\n open() call failed- errno = %d\n",errno);
        perror("Error in crating");
    }
    else {
        printf("\nOpen() call is successful\n");
    }
    return 0;
}