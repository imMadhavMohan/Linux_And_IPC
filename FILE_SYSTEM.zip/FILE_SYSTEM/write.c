#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<malloc.h>
#include<unistd.h>
#include<string.h>

int main(){
    int sz;
    char buf[100]={0};

    strcpy(buf,"Hi Maddy Mohan Come here boy, sit here");
    // O_TRUNC : write from begin erase old 
    // O_APPEND : write the contents of the end of file

    int fd = open("text.txt", O_WRONLY | O_APPEND | O_RDONLY); // O_WRONLY can be used
    if(fd<0){
        printf("\nError in creation\n");
        exit(1);
    }
    printf("length of buf: %d",(int)strlen(buf));
    sz = write(fd, buf, strlen(buf));

    printf("\nwrite() return bytes: %d\n", sz);
        
    int r = read(fd,buf, 10);
    buf[sz] = '\0';
    printf("Read: %s\n",buf);
    
    strcpy(buf,"Hi you work in Luxoft I think If I'm not wrong\n");
    fd = open("text.txt",O_WRONLY | O_TRUNC);
    sz = write(fd, buf, strlen(buf));

    r = read(fd, buf, 10);
    printf("Read: %s\n",buf);

    return 0;
}