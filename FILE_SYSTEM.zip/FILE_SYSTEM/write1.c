#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<string.h>
#include<malloc.h>
#include<unistd.h>

int main(){
    int sz;
    char buf[100]={0};

    strcpy(buf,"Hi Maddy Mohan Come here boy, sit here you are awesome yar you");
    // O_TRUNC : write from begin erase old 
    // O_APPEND : write the contents of the end of file

    int fd = open("file1.txt", O_WRONLY | O_APPEND | O_CREAT | O_EXCL, 0774); // O_WRONLY can be used
    if(fd<0){
        printf("\nError in creation!\n");
        exit(1);
    }

    int r = read(fd, buf, 10); // read 10 byte
    printf("\nRead: %s\n", buf);

    return 0;
}