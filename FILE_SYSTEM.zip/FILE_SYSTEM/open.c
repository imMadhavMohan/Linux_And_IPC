#include<stdio.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<errno.h>

int main(){
    int fd = open("sys",O_WRONLY); // got the file
    if(fd<0){ // if file permission contradicts then also error comes
        printf("\n open() call failed- errno = %d\n",errno);
        perror("Error in crating");
    }
    else {
        printf("\nOpen() call is successful\n");
    }
    return 0;
}