#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
#include<string.h>
#include<stdlib.h>
#include<malloc.h>

int main(){
    int fd; char buf[5]="Mohan\n";
    fd = open("author.txt",O_RDWR|O_EXCL);

    int seek_pos;
    // This course is all about Linux system programming. The instructor of this course is Rohan
    seek_pos = lseek(fd, -5, SEEK_END); // point to end, now cursor pointer is pointing @ 84th index
    printf("seek pos: %d",seek_pos);
    
    int wr = write(fd,buf,strlen(buf)); // now cursor pointer is pointing @ 84th index

}