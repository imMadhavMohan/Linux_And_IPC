#include <stdio.h>  
#include <stdlib.h>  
#include <string.h>   

int main(int arg, char* argv[]){
    int cnt = 0;    
    printf("the val of arg: %d\n",arg);
    
    if(strstr(argv[1],"add")) // arg[0] has file name
        printf("Sum is: %d\n",atoi(argv[2])+atoi(argv[3]));    
    else if(strstr(argv[1],"sub"))
        printf("Sub is: %d\n",atoi(argv[2])-atoi(argv[3]));
    else 
        printf("Wrong Input");
    printf("\n");
    return 0;    
}