#include<stdio.h>
#include<fcntl.h>
#include<string.h>

int main(int arg, char* argv[]){
    int cnt = 0;
    printf("\nShow the cmd_arg: ");
    printf("the val of arg: %d",arg);
    while (cnt<arg)
    {
      printf("\n (%d) the string is: %s",cnt,argv[cnt]);
      cnt++;
    }
    printf("\n");
    return 0;    
}