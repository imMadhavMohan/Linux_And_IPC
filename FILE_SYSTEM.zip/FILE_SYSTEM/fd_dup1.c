#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>

int main()
{
    int fd, fd_dup;
    fd = open("file.txt", O_RDWR | O_APPEND);

    int w1 = write(fd, "Happly Goverdan + Diwali dear!\0\n", 45);

    fd_dup = dup2(fd, 1); // newfd & oldfd will be point to same file
    int w2 = write(fd_dup, "Happy Holi + Diwali\0\n", 45); 
    close(fd);
    printf("Old_fd: %d , new_fd: %d\n", fd, fd_dup);

    return 0;
}
