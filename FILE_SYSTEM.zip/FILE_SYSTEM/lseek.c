#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
#include<string.h>
#include<stdlib.h>
#include<malloc.h>

int main(){
    int fd;
    char buf[100]={0}; int seek_pos = 0, sz;

    fd = open("file.txt", O_WRONLY | O_EXCL);
    if(fd<0){
        perror("ERROR:\n");
        exit(1);
    }
    
    seek_pos = lseek(fd, 0, SEEK_SET); // byte to be moved = 0, SEEK_SET = point to the beginning of 1st-byte of file
    printf("\nInitial offset pos: %d\n",seek_pos);

    seek_pos = lseek(fd, 2, SEEK_SET); // byte move = 2, SEEK_SET = point to the beginning byte of file2
    printf("\nOffset pos with offset 2+0: %d\n",seek_pos);

    seek_pos = lseek(fd, 6, SEEK_CUR); // byte move = 6, SEEK_CUR = 2 = point to the curr pos byte of file2
    printf("\nOffset pos with offset+2: %d\n",seek_pos);

    strcpy(buf,"Hello Madhav Come & we'll discuss code!");
    sz = read(fd, buf, 4);    // return read byte from file
    buf[sz]='\0';
    printf("\nRead: %s\n",buf);

    seek_pos = lseek(fd, 0, SEEK_END); // pos = 0+end byte = @ end
    printf("\nOffset pos (0+seek_end): %d\n", seek_pos);

    strcpy(buf, "New string appended after SEEK END\n");
    sz = write(fd, buf, strlen(buf));
    
    close(fd);

    return 0;
}
