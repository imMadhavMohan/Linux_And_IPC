#include<stdio.h>
#include<unistd.h>
#include<string.h>

extern char **enviorm;

int main(){
    char** ep;
    for(ep=enviorm; *ep!=NULL; ep++)
        printf("\n (%s)",*ep);
    
    printf("PATH: (%s)\n",getenv("PATH"));
    printf("PATH: (%s)\n",getenv("HOME"));

    putenv("PARAM = 1024");
    printf("\nPATH: (%s)\n",getenv("PARAM"));

    return 0;
}