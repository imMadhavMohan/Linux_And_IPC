// A C program to demonstrate Zombie Process.

#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>

// child's exit status is never read by the parent and the child's entry continues to remain 
// there in the process table even when the child has died

int main()
{
	// Fork returns process id in parent process
	
    pid_t child_pid = fork();

	// Parent process
	if (child_pid > 0)
		sleep(60);

	// Child process
	else		
		exit(0);

	return 0;
}
