#include<unistd.h>
#include<string.h>

int main(){
    size_t len;
    char buf[100];
    strncpy(buf,"Hi I'm good boy!\n",99);
    int msg_len = strlen(buf);
    write(0,buf,99); // system call
}