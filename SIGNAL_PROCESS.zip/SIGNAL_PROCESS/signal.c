#include<sys/types.h>
#include<unistd.h>
#include<signal.h>
#include<stdlib.h>
#include<stdio.h>

static void signal_handler(int signo){
    if(signo==SIGTERM){
        printf("Caught Sigterm\n");
    }
    else if(signo==SIGINT){
        printf("Caught Sigint\n");
    }
    exit(EXIT_SUCCESS);
}

int main(){
    printf("Parent id: %d",getpid());
    if(signal(SIGINT, SIG_IGN)==SIG_ERR){ // ctrl + c the  
        fprintf(stderr, "Can't ignore sighup!\n");
        exit(EXIT_SUCCESS);
    }

    if(signal(SIGTERM, signal_handler)==SIG_ERR){ // kill -15 pid control move to handler
        fprintf(stderr, "Can't handle sigterm!\n");
        exit(EXIT_SUCCESS);
    }
    while(1);
    printf("\n");
    return 0;
}