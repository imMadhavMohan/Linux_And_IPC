#include<sys/types.h>
#include<unistd.h>
#include<signal.h>
#include<stdlib.h>
#include<stdio.h>

static void display_msg(int signo){
    printf("Caught SigAlrm\n");
    signal(SIGALRM, SIG_IGN); // Halt and trapp in to while
    // signal(SIGALRM, SIG_DFL); // no repeatation as terminate in default manner

    alarm(2);    // repeat after 2sec
}

int main(){
    printf("Parent id: %d\n",getpid());
    signal(SIGALRM, display_msg);     // ctrl + c
    alarm(2);

    while(1);    
    return 0;
}