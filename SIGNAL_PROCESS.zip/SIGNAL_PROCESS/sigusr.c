#include<stdio.h>
#include<unistd.h>
#include<signal.h>
#include<stdlib.h>

static void signal_handler(int signo){
    if(signo==SIGUSR2){
        printf("Parent SIGUSR2 signal caught in child: %d\n",SIGUSR2);
    }
}

int main(int arg, char* argv[]){    
    printf("Child:\nI'm a new process called by excel()\n");
    printf("Chid new progrm id: %d\n",getpid());

    if(signal(SIGUSR2, signal_handler)==SIG_ERR){
        fprintf(stderr,"can't handle sigusr2\n");
        exit(-1);
    }
    for(int i=0;i<arg;i++){
        printf("\nChild: argc[%d] = %s\n",i,argv[i]);
    }

    sleep(5);
    printf("child sends sigusr1 to parent\n");
    kill(getppid(), SIGUSR1);
    sleep(5);
    printf("Child exited\n\n");
    
    return 0;
}